// Simple WMS JavaScript
(function() {
    'use strict';

    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        initializeApp();
    });

    function initializeApp() {
        initializeNavigation();
        initializeModals();
        initializeTooltips();
        console.log('WMS App Initialized');
    }

    // Navigation functions
    function initializeNavigation() {
        // Sidebar collapse functionality
        const collapseElements = document.querySelectorAll('[data-bs-toggle="collapse"]');
        collapseElements.forEach(element => {
            element.addEventListener('click', function() {
                const chevron = this.querySelector('.fa-chevron-down');
                if (chevron) {
                    setTimeout(() => {
                        const target = document.querySelector(this.getAttribute('data-bs-target'));
                        if (target) {
                            const isShown = target.classList.contains('show');
                            chevron.style.transform = isShown ? 'rotate(180deg)' : 'rotate(0deg)';
                        }
                    }, 150);
                }
            });
        });
    }

    // Modal functions
    function initializeModals() {
        // Auto-add first item row when modals are shown
        ['receivingModal', 'assignmentModal', 'disposalModal'].forEach(modalId => {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.addEventListener('shown.bs.modal', function() {
                    const itemsContainer = this.querySelector('.items-container');
                    if (itemsContainer && itemsContainer.children.length === 0) {
                        addModalItem(modalId);
                    }
                });
            }
        });
    }

    // Tooltip initialization
    function initializeTooltips() {
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        if (typeof bootstrap !== 'undefined') {
            tooltipTriggerList.forEach(function(tooltipTriggerEl) {
                new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }
    }

    // Global functions
    window.openModal = function(modalId) {
        const modalElement = document.getElementById(modalId);
        if (modalElement && typeof bootstrap !== 'undefined') {
            const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
            modal.show();
        }
    };

    window.addModalItem = function(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        const itemsContainer = modal.querySelector('.items-container');
        if (!itemsContainer) return;

        const itemRow = document.createElement('div');
        itemRow.className = 'modal-item-row border rounded p-3 mb-3 bg-light';
        itemRow.innerHTML = `
            <div class="row align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Item</label>
                    <select class="form-select" name="id_barang" required>
                        <option value="">Select Item</option>
                        <option value="1">Lenovo ThinkPad E14 - Laptop</option>
                        <option value="2">Logitech MX Master 3 - Mouse</option>
                        <option value="3">ASUS VA24EHE - Monitor</option>
                        <option value="4">Dell OptiPlex 3080 - Desktop PC</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Quantity</label>
                    <input type="number" class="form-control" name="qty_stok" min="1" value="1" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Notes</label>
                    <input type="text" class="form-control" name="keterangan" placeholder="Optional notes">
                </div>
                <div class="col-md-2">
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeModalItem(this)">
                        <i class="fas fa-trash"></i> Remove
                    </button>
                </div>
            </div>
        `;
        
        itemsContainer.appendChild(itemRow);
    };

    window.removeModalItem = function(button) {
        const itemRow = button.closest('.modal-item-row');
        if (itemRow) {
            itemRow.remove();
        }
    };

    window.createTransaction = function(type) {
        const form = document.getElementById(`${type}Form`);
        if (!form) return;

        const formData = new FormData(form);
        const data = {
            npk: formData.get('npk') || formData.get('created_by'),
            id_gudang: formData.get('id_gudang'),
            keterangan: formData.get('keterangan') || formData.get('catatan'),
            items: []
        };

        // Get items from form
        const itemRows = form.querySelectorAll('.modal-item-row');
        itemRows.forEach(row => {
            const id_barang = row.querySelector('select[name="id_barang"]')?.value;
            const qty_stok = row.querySelector('input[name="qty_stok"]')?.value;
            const keterangan = row.querySelector('input[name="keterangan"]')?.value;
            
            if (id_barang && qty_stok) {
                data.items.push({
                    id_barang: parseInt(id_barang),
                    qty_stok: parseInt(qty_stok),
                    keterangan: keterangan
                });
            }
        });

        if (!data.npk || !data.id_gudang || data.items.length === 0) {
            showAlert('Error', 'Please fill in all required fields and add at least one item.', 'danger');
            return;
        }

        showLoading('Processing transaction...');

        fetch(`/api/transaksi/${type}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            hideLoading();
            if (result.success) {
                showAlert('Success', result.message, 'success');
                closeModal(`${type}Modal`);
                setTimeout(() => {
                    if (window.location.pathname.includes('transaksi')) {
                        window.location.reload();
                    }
                }, 1500);
            } else {
                showAlert('Error', result.message, 'danger');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('Transaction error:', error);
            showAlert('Error', 'Transaction failed. Please try again.', 'danger');
        });
    };

    window.refreshTransactions = function() {
        window.location.reload();
    };

    window.refreshDashboard = function() {
        showLoading('Refreshing dashboard...');
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    };

    window.refreshLowStock = function() {
        showLoading('Refreshing low stock data...');
        setTimeout(() => {
            hideLoading();
            showAlert('Success', 'Low stock data refreshed', 'success');
        }, 1500);
    };

    window.exportLowStock = function() {
        showLoading('Preparing export...');
        
        // Simple CSV export
        let csvContent = "Item Name,Category,Stock,Warehouse\n";
        csvContent += "Logitech MX Master 3,Mouse,2,Gudang IT Utama\n";
        csvContent += "Lenovo ThinkPad E14,Laptop,1,Gudang IT Utama\n";
        csvContent += "ASUS VA24EHE Monitor,Monitor,3,Gudang Cadangan\n";
        
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `low_stock_report_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        hideLoading();
        showAlert('Success', 'Low stock report exported successfully', 'success');
    };

    window.viewItem = function(itemId) {
        showAlert('Info', `Viewing item ${itemId} - Feature will be implemented soon`, 'info');
    };

    window.quickRestock = function(itemId) {
        showAlert('Info', `Quick restock for item ${itemId} - Redirecting to transactions page`, 'info');
        setTimeout(() => {
            window.location.href = '/transaksi';
        }, 1500);
    };

    window.logout = function() {
        if (confirm('Are you sure you want to logout?')) {
            showAlert('Info', 'Logout functionality will be implemented', 'info');
        }
    };

    window.viewTransactionDetails = function(transactionId) {
        showLoading('Loading transaction details...');
        
        fetch(`/api/transaksi/${transactionId}`)
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    displayTransactionDetails(data.data);
                    openModal('transactionDetailsModal');
                } else {
                    showAlert('Error', data.message, 'danger');
                }
            })
            .catch(error => {
                hideLoading();
                console.error('Error loading transaction details:', error);
                showAlert('Error', 'Failed to load transaction details', 'danger');
            });
    };

    function displayTransactionDetails(data) {
        const { transaction } = data;
        const content = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Transaction Information</h6>
                    <table class="table table-sm">
                        <tr><td>Code:</td><td><strong>${transaction.kode_transaksi}</strong></td></tr>
                        <tr><td>Type:</td><td><span class="badge bg-primary">${transaction.jenis_transaksi.toUpperCase()}</span></td></tr>
                        <tr><td>Date:</td><td>${new Date(transaction.tanggal_transaksi).toLocaleString()}</td></tr>
                        <tr><td>Status:</td><td><span class="badge bg-success">${transaction.status.toUpperCase()}</span></td></tr>
                        <tr><td>Employee:</td><td>${transaction.karyawan_nama || 'N/A'}</td></tr>
                        <tr><td>Warehouse:</td><td>${transaction.nama_gudang || 'N/A'}</td></tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Additional Information</h6>
                    <table class="table table-sm">
                        <tr><td>Total Items:</td><td>${transaction.total_item || 0}</td></tr>
                        <tr><td>Total Value:</td><td>Rp ${(transaction.total_nilai || 0).toLocaleString()}</td></tr>
                        <tr><td>Notes:</td><td>${transaction.keterangan || 'No notes'}</td></tr>
                    </table>
                </div>
            </div>
        `;
        
        const detailsElement = document.getElementById('transactionDetailsContent');
        if (detailsElement) {
            detailsElement.innerHTML = content;
        }
    }

    window.updateTransactionStatus = function(transactionId, status) {
        if (!confirm(`Are you sure you want to ${status} this transaction?`)) {
            return;
        }
        
        showLoading(`Updating transaction to ${status}...`);
        
        setTimeout(() => {
            hideLoading();
            showAlert('Success', `Transaction ${status} successfully!`, 'success');
            setTimeout(() => window.location.reload(), 1000);
        }, 1500);
    };

    window.printTransaction = function(transactionId) {
        showAlert('Info', 'Print functionality will be implemented', 'info');
    };

    window.filterTransactions = function() {
        // Simple client-side filtering
        const type = document.getElementById('filterType')?.value.toLowerCase();
        const status = document.getElementById('filterStatus')?.value.toLowerCase();
        
        const table = document.getElementById('transactionsTable');
        if (!table) return;
        
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            let show = true;
            const rowText = row.textContent.toLowerCase();
            
            if (type && !rowText.includes(type)) {
                show = false;
            }
            
            if (status && !rowText.includes(status)) {
                show = false;
            }
            
            row.style.display = show ? '' : 'none';
        });
    };

    window.searchTransactions = function() {
        const searchTerm = document.getElementById('searchTransactions')?.value.toLowerCase();
        if (!searchTerm) return;
        
        const table = document.getElementById('transactionsTable');
        if (!table) return;
        
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    };

    window.exportTransactions = function() {
        showLoading('Preparing export...');
        
        setTimeout(() => {
            hideLoading();
            showAlert('Success', 'Transactions exported successfully', 'success');
        }, 1500);
    };

    // Utility functions
    function showLoading(message = 'Loading...') {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            const messageEl = overlay.querySelector('.mt-3');
            if (messageEl) messageEl.textContent = message;
            overlay.classList.remove('d-none');
        }
    }

    function hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('d-none');
        }
    }

    function showAlert(title, message, type = 'info') {
        // Create alert toast
        const alertHtml = `
            <div class="toast align-items-center text-white bg-${type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        <strong>${title}</strong><br>
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        `;
        
        let toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toastContainer';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '2000';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.insertAdjacentHTML('beforeend', alertHtml);
        
        const toastElement = toastContainer.lastElementChild;
        if (typeof bootstrap !== 'undefined') {
            const toast = new bootstrap.Toast(toastElement);
            toast.show();
            
            toastElement.addEventListener('hidden.bs.toast', () => {
                toastElement.remove();
            });
        }
    }

    function closeModal(modalId) {
        const modalElement = document.getElementById(modalId);
        if (modalElement && typeof bootstrap !== 'undefined') {
            const modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
            }
        }
    }

})();