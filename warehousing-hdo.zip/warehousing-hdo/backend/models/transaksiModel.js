const { query, getClient } = require('../config/db');

class TransaksiModel {
  // Get all transactions
  static async getAll(statusFilter = null, limit = 100, offset = 0) {
    let sql = `
      SELECT 
        t.kode_transaksi,
        t.id_barang,
        t.jenis_barang,
        t.nama_barang,
        t.npk,
        t.nama,
        t.status_barang,
        t.qty_stok,
        t.tanggal,
        t.keterangan,
        g.nama_gudang,
        b.spesifikasi
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN barang b ON t.id_barang = b.id_barang
    `;
    
    const params = [];
    
    if (statusFilter) {
      sql += ` WHERE t.status_barang = $1`;
      params.push(statusFilter);
    }
    
    sql += `
      ORDER BY t.tanggal DESC, t.kode_transaksi DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;
    
    params.push(limit, offset);
    
    try {
      const result = await query(sql, params);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transactions: ${error.message}`);
    }
  }

  // Get transaction by ID
  static async getById(id) {
    const sql = `
      SELECT 
        t.*,
        g.nama_gudang,
        b.spesifikasi
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      WHERE t.kode_transaksi = $1
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting transaction by ID: ${error.message}`);
    }
  }

  // Create new transaction
  static async create(transactionData) {
    const {
      id_barang,
      npk,
      status_barang, // 'Masuk', 'Assignment', 'Disposal'
      qty_stok,
      id_gudang,
      keterangan
    } = transactionData;

    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Get barang and karyawan info
      const barangResult = await client.query('SELECT jenis_barang, nama_barang FROM barang WHERE id_barang = $1', [id_barang]);
      const karyawanResult = await client.query('SELECT nama FROM karyawan WHERE npk = $1', [npk]);
      
      if (!barangResult.rows[0]) {
        throw new Error('Item not found');
      }
      
      if (!karyawanResult.rows[0]) {
        throw new Error('Employee not found');
      }
      
      const barang = barangResult.rows[0];
      const karyawan = karyawanResult.rows[0];
      
      // Create transaction
      const transactionSql = `
        INSERT INTO transaksi 
        (id_barang, jenis_barang, nama_barang, npk, nama, status_barang, qty_stok, id_gudang, keterangan)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
      
      const result = await client.query(transactionSql, [
        id_barang,
        barang.jenis_barang,
        barang.nama_barang,
        npk,
        karyawan.nama,
        status_barang,
        qty_stok,
        id_gudang,
        keterangan
      ]);
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error creating transaction: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Create batch transactions (for multiple items in one operation)
  static async createBatch(transactionDataArray) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      const results = [];
      
      for (const transactionData of transactionDataArray) {
        const {
          id_barang,
          npk,
          status_barang,
          qty_stok,
          id_gudang,
          keterangan
        } = transactionData;
        
        // Get barang and karyawan info
        const barangResult = await client.query('SELECT jenis_barang, nama_barang FROM barang WHERE id_barang = $1', [id_barang]);
        const karyawanResult = await client.query('SELECT nama FROM karyawan WHERE npk = $1', [npk]);
        
        if (!barangResult.rows[0] || !karyawanResult.rows[0]) {
          throw new Error(`Item or employee not found for item ID: ${id_barang}`);
        }
        
        const barang = barangResult.rows[0];
        const karyawan = karyawanResult.rows[0];
        
        // Create transaction
        const transactionSql = `
          INSERT INTO transaksi 
          (id_barang, jenis_barang, nama_barang, npk, nama, status_barang, qty_stok, id_gudang, keterangan)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
          RETURNING *
        `;
        
        const result = await client.query(transactionSql, [
          id_barang,
          barang.jenis_barang,
          barang.nama_barang,
          npk,
          karyawan.nama,
          status_barang,
          qty_stok,
          id_gudang,
          keterangan
        ]);
        
        results.push(result.rows[0]);
      }
      
      await client.query('COMMIT');
      
      return results;
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error creating batch transactions: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Update transaction
  static async update(id, updateData) {
    const {
      status_barang,
      qty_stok,
      id_gudang,
      keterangan
    } = updateData;

    const sql = `
      UPDATE transaksi 
      SET status_barang = $2, qty_stok = $3, id_gudang = $4, keterangan = $5
      WHERE kode_transaksi = $1
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [id, status_barang, qty_stok, id_gudang, keterangan]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating transaction: ${error.message}`);
    }
  }

  // Delete transaction
  static async delete(id) {
    const sql = 'DELETE FROM transaksi WHERE kode_transaksi = $1 RETURNING *';
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting transaction: ${error.message}`);
    }
  }

  // Get dashboard statistics
  static async getDashboardStats() {
    const sql = `
      SELECT 
        COUNT(*) as total_transactions,
        COUNT(CASE WHEN status_barang = 'Masuk' THEN 1 END) as total_masuk,
        COUNT(CASE WHEN status_barang = 'Assignment' THEN 1 END) as total_assignment,
        COUNT(CASE WHEN status_barang = 'Disposal' THEN 1 END) as total_disposal,
        SUM(CASE WHEN status_barang = 'Masuk' THEN qty_stok ELSE 0 END) as qty_masuk,
        SUM(CASE WHEN status_barang = 'Assignment' THEN qty_stok ELSE 0 END) as qty_assignment,
        SUM(CASE WHEN status_barang = 'Disposal' THEN qty_stok ELSE 0 END) as qty_disposal,
        COUNT(DISTINCT id_barang) as unique_items,
        COUNT(DISTINCT npk) as unique_employees,
        COUNT(DISTINCT id_gudang) as active_warehouses
      FROM transaksi
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting dashboard statistics: ${error.message}`);
    }
  }

  // Get recent transactions
  static async getRecentTransactions(limit = 10) {
    const sql = `
      SELECT 
        t.kode_transaksi,
        t.jenis_barang,
        t.nama_barang,
        t.nama,
        t.status_barang,
        t.qty_stok,
        t.tanggal,
        g.nama_gudang
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      ORDER BY t.tanggal DESC
      LIMIT $1
    `;
    
    try {
      const result = await query(sql, [limit]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting recent transactions: ${error.message}`);
    }
  }

  // Get transactions by employee NPK
  static async getByEmployee(npk) {
    const sql = `
      SELECT 
        t.*,
        g.nama_gudang,
        b.spesifikasi
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      WHERE t.npk = $1
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [npk]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transactions by employee: ${error.message}`);
    }
  }

  // Get transactions by warehouse
  static async getByWarehouse(warehouseId) {
    const sql = `
      SELECT 
        t.*,
        g.nama_gudang,
        b.spesifikasi
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      WHERE t.id_gudang = $1
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [warehouseId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transactions by warehouse: ${error.message}`);
    }
  }

  // Get transactions by item
  static async getByItem(itemId) {
    const sql = `
      SELECT 
        t.*,
        g.nama_gudang
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE t.id_barang = $1
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [itemId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transactions by item: ${error.message}`);
    }
  }

  // Search transactions
  static async search(searchTerm) {
    const sql = `
      SELECT 
        t.*,
        g.nama_gudang
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE 
        LOWER(t.nama_barang) LIKE LOWER($1) OR
        LOWER(t.jenis_barang) LIKE LOWER($1) OR
        LOWER(t.nama) LIKE LOWER($1) OR
        LOWER(t.npk) LIKE LOWER($1) OR
        LOWER(t.keterangan) LIKE LOWER($1) OR
        LOWER(g.nama_gudang) LIKE LOWER($1)
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching transactions: ${error.message}`);
    }
  }

  // Get transactions by date range
  static async getByDateRange(startDate, endDate) {
    const sql = `
      SELECT 
        t.*,
        g.nama_gudang
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE DATE(t.tanggal) BETWEEN $1 AND $2
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [startDate, endDate]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transactions by date range: ${error.message}`);
    }
  }

  // Get transaction summary by status
  static async getSummaryByStatus() {
    const sql = `
      SELECT 
        status_barang,
        COUNT(*) as count,
        SUM(qty_stok) as total_qty,
        COUNT(DISTINCT id_barang) as unique_items,
        COUNT(DISTINCT npk) as unique_employees
      FROM transaksi
      GROUP BY status_barang
      ORDER BY status_barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transaction summary by status: ${error.message}`);
    }
  }

  // Get monthly transaction summary
  static async getMonthlyStats(year = null) {
    let sql = `
      SELECT 
        EXTRACT(YEAR FROM tanggal) as year,
        EXTRACT(MONTH FROM tanggal) as month,
        status_barang,
        COUNT(*) as count,
        SUM(qty_stok) as total_qty
      FROM transaksi
    `;
    
    const params = [];
    
    if (year) {
      sql += ` WHERE EXTRACT(YEAR FROM tanggal) = $1`;
      params.push(year);
    }
    
    sql += `
      GROUP BY EXTRACT(YEAR FROM tanggal), EXTRACT(MONTH FROM tanggal), status_barang
      ORDER BY year DESC, month DESC, status_barang
    `;
    
    try {
      const result = await query(sql, params);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting monthly transaction statistics: ${error.message}`);
    }
  }

  // Check stock availability before assignment/disposal
  static async checkStockAvailability(itemId, warehouseId, requiredQty) {
    const sql = `
      SELECT 
        b.nama_barang,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as available_stock
      FROM barang b
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE status_barang = 'Masuk' AND id_gudang = $2
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE status_barang IN ('Assignment', 'Disposal') AND id_gudang = $2
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.id_barang = $1
    `;
    
    try {
      const result = await query(sql, [itemId, warehouseId]);
      const stock = result.rows[0];
      
      if (!stock) {
        return { available: false, message: 'Item not found', currentStock: 0 };
      }
      
      const availableStock = stock.available_stock || 0;
      
      if (availableStock < requiredQty) {
        return { 
          available: false, 
          message: `Insufficient stock. Available: ${availableStock}, Required: ${requiredQty}`,
          currentStock: availableStock
        };
      }
      
      return { 
        available: true, 
        message: 'Stock available',
        currentStock: availableStock
      };
    } catch (error) {
      throw new Error(`Error checking stock availability: ${error.message}`);
    }
  }

  // Generate transaction report
  static async generateReport(filters = {}) {
    const { 
      startDate, 
      endDate, 
      status_barang, 
      warehouseId, 
      employeeNpk,
      itemType 
    } = filters;

    let sql = `
      SELECT 
        t.kode_transaksi,
        t.tanggal,
        t.jenis_barang,
        t.nama_barang,
        t.npk,
        t.nama,
        t.status_barang,
        t.qty_stok,
        t.keterangan,
        g.nama_gudang,
        b.spesifikasi
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (startDate) {
      paramCount++;
      sql += ` AND DATE(t.tanggal) >= ${paramCount}`;
      params.push(startDate);
    }

    if (endDate) {
      paramCount++;
      sql += ` AND DATE(t.tanggal) <= ${paramCount}`;
      params.push(endDate);
    }

    if (status_barang) {
      paramCount++;
      sql += ` AND t.status_barang = ${paramCount}`;
      params.push(status_barang);
    }

    if (warehouseId) {
      paramCount++;
      sql += ` AND t.id_gudang = ${paramCount}`;
      params.push(warehouseId);
    }

    if (employeeNpk) {
      paramCount++;
      sql += ` AND t.npk = ${paramCount}`;
      params.push(employeeNpk);
    }

    if (itemType) {
      paramCount++;
      sql += ` AND LOWER(t.jenis_barang) = LOWER(${paramCount})`;
      params.push(itemType);
    }

    sql += ` ORDER BY t.tanggal DESC, t.kode_transaksi DESC`;

    try {
      const result = await query(sql, params);
      return result.rows;
    } catch (error) {
      throw new Error(`Error generating transaction report: ${error.message}`);
    }
  }
}

module.exports = TransaksiModel;