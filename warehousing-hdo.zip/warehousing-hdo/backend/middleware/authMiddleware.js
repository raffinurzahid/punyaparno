// Auth middleware pakai JWT
const jwt = require('jsonwebtoken');
const KaryawanModel = require('../models/karyawanModel');

const JWT_SECRET = process.env.JWT_SECRET || 'supersecret'; // simpan di .env
const JWT_EXPIRES_IN = '24h'; // bisa atur sesuai kebutuhan

// Middleware cek token
const requireAuth = async (req, res, next) => {
  try {
    const token =
      req.headers['authorization']?.replace('Bearer ', '') ||
      req.cookies?.token;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Token tidak ditemukan. Silakan login terlebih dahulu.'
      });
    }

    // verifikasi token
    const decoded = jwt.verify(token, JWT_SECRET);

    // ambil data user fresh dari DB
    const user = await KaryawanModel.getById(decoded.userId);

    if (!user || user.status !== 'aktif') {
      return res.status(401).json({
        success: false,
        message: 'User tidak aktif atau tidak ditemukan.'
      });
    }

    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({
      success: false,
      message: 'Token tidak valid atau expired.'
    });
  }
};

// Middleware opsional (kalau token ada dipakai, kalau nggak lanjut aja)
const optionalAuth = async (req, res, next) => {
  try {
    const token =
      req.headers['authorization']?.replace('Bearer ', '') ||
      req.cookies?.token;

    if (token) {
      const decoded = jwt.verify(token, JWT_SECRET);
      const user = await KaryawanModel.getById(decoded.userId);
      if (user && user.status === 'aktif') {
        req.user = user;
        req.token = token;
      }
    }
    next();
  } catch {
    next(); // lanjut tanpa user
  }
};

// Role check
const requireRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Authentication required.' });
    }

    const userRole = req.user.posisi?.toLowerCase();
    const userDivision = req.user.divisi?.toLowerCase();

    const isAllowed = allowedRoles.some(role => {
      const normalized = role.toLowerCase();
      return userRole === normalized ||
             userDivision === normalized ||
             `${userDivision} ${userRole}`.includes(normalized);
    });

    if (!isAllowed) {
      return res.status(403).json({ success: false, message: 'Anda tidak punya akses.' });
    }

    next();
  };
};

// Login → generate JWT
const login = async (req, res) => {
  try {
    const { nip, password } = req.body;
    if (!nip) {
      return res.status(400).json({ success: false, message: 'NIP harus diisi.' });
    }

    const user = await KaryawanModel.getByNip(nip);
    if (!user) return res.status(401).json({ success: false, message: 'NIP tidak ditemukan.' });
    if (user.status !== 'aktif') {
      return res.status(401).json({ success: false, message: 'Akun tidak aktif.' });
    }

    // contoh: cek divisi
    if (user.divisi?.toLowerCase() !== 'help desk operation') {
      return res.status(403).json({ success: false, message: 'Hanya Help Desk Operation.' });
    }

    // generate JWT
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    const userResponse = { ...user };
    delete userResponse.password;

    res.json({
      success: true,
      message: 'Login berhasil',
      data: {
        user: userResponse,
        token,
        expires_in: JWT_EXPIRES_IN
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Terjadi kesalahan saat login.' });
  }
};

// Logout → di JWT cukup hapus token di client
const logout = (req, res) => {
  res.json({ success: true, message: 'Logout berhasil (hapus token di client)' });
};

// Get current user
const getCurrentUser = (req, res) => {
  if (!req.user) {
    return res.status(401).json({ success: false, message: 'Not authenticated' });
  }
  const userResponse = { ...req.user };
  delete userResponse.password;
  res.json({ success: true, data: userResponse });
};

module.exports = {
  requireAuth,
  optionalAuth,
  requireRole,
  login,
  logout,
  getCurrentUser
};
