const { Pool } = require('pg');
require('dotenv').config();

// Database connection configuration
const dbConfig = process.env.DATABASE_URL
  ? {
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    }
  : {
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 5432,
      database: process.env.DB_NAME || 'db_wms',
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    };

// Create connection pool
const pool = new Pool(dbConfig);

// Test database connection
const testConnection = async () => {
  try {
    const client = await pool.connect();
    console.log('✅ Database connected successfully');

    // Test query
    const result = await client.query('SELECT NOW()');
    console.log('📅 Database time:', result.rows[0].now);

    client.release();
  } catch (err) {
    console.error('❌ Database connection error:', err.message);
    console.error('🔧 Please check your database configuration in .env file or DATABASE_URL');
  }
};

// Query helper function
const query = async (text, params) => {
  const start = Date.now();

  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;

    if (process.env.NODE_ENV === 'development') {
      console.log('📊 Query executed:', { text, duration: `${duration}ms`, rows: result.rowCount });
    }

    return result;
  } catch (err) {
    console.error('❌ Query error:', err.message);
    console.error('🔍 Query:', text);
    console.error('📝 Params:', params);
    throw err;
  }
};

// Get client from pool (for transactions)
const getClient = async () => {
  try {
    const client = await pool.connect();
    return client;
  } catch (err) {
    console.error('❌ Failed to get database client:', err.message);
    throw err;
  }
};

// Graceful shutdown
const closePool = async () => {
  try {
    await pool.end();
    console.log('🔌 Database connection pool closed');
  } catch (err) {
    console.error('❌ Error closing database pool:', err.message);
  }
};

process.on('SIGINT', closePool);
process.on('SIGTERM', closePool);

module.exports = {
  pool,
  query,
  getClient,
  testConnection,
  closePool,
};