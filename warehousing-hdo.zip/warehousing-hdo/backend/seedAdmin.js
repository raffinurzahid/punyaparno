const bcrypt = require('bcrypt');
const { Pool } = require('pg');
require('dotenv').config();

// Koneksi ke PostgreSQL
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Data admin default
const admin = {
  username: 'admin',
  password: 'admin123', // default password (nanti di-hash)
  role: 'admin'
};

async function seedAdmin() {
  try {
    const hashedPassword = await bcrypt.hash(admin.password, 10);

    // Drop tabel kalau ada, lalu buat ulang
    await pool.query(`DROP TABLE IF EXISTS admin`);

    await pool.query(`
      CREATE TABLE admin (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'admin',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Insert admin default
    await pool.query(
      `INSERT INTO admin (username, password, role) VALUES ($1, $2, $3)`,
      [admin.username, hashedPassword, admin.role]
    );

    console.log('✅ Tabel admin berhasil dibuat ulang dan admin default ditambahkan!');
    pool.end();
  } catch (err) {
    console.error('❌ Error seeding admin:', err);
    pool.end();
  }
}

seedAdmin();