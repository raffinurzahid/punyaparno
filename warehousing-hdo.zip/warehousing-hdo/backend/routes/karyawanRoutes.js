// karyawanRoutes.js
const express = require('express');
const router = express.Router();

const KaryawanController = {
  getAll: (req, res) => {
    // Implementation would call KaryawanModel.getAll()
    res.json({ success: true, data: [] });
  },
  
  getById: (req, res) => {
    const { id } = req.params;
    res.json({ success: true, data: { id, nama: 'Sample Employee' } });
  }
};

router.get('/', KaryawanController.getAll);
router.get('/:id', KaryawanController.getById);

module.exports = router;