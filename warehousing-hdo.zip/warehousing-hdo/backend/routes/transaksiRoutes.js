const express = require('express');
const router = express.Router();
const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

let createTransactionNotification = null;

const setNotificationCreator = (notificationCreator) => {
  createTransactionNotification = notificationCreator;
};

// =======================
// GET Semua Transaksi
// =======================
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10, type, status, date } = req.query;
    
    // FIXED: Join dengan tabel gudang untuk mendapatkan nama_gudang
    let queryStr = `
      SELECT t.*, g.nama_gudang 
      FROM transaksi t 
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang 
      WHERE 1=1
    `;
    const queryParams = [];
    let paramCount = 0;

    if (type) {
      paramCount++;
      if (type === 'RCV') {
        queryStr += ` AND t.status_barang = $${paramCount}`;
        queryParams.push('Masuk');
      } else if (type === 'ASS') {
        queryStr += ` AND t.status_barang = $${paramCount}`;
        queryParams.push('Assignment');
      } else if (type === 'DISP') {
        queryStr += ` AND t.status_barang = $${paramCount}`;
        queryParams.push('Disposal');
      }
    }

    if (status) {
      paramCount++;
      if (status === 'In Store') {
        queryStr += ` AND t.status_barang = $${paramCount}`;
        queryParams.push('Masuk');
      } else if (status === 'In Use') {
        queryStr += ` AND t.status_barang = $${paramCount}`;
        queryParams.push('Assignment');
      } else if (status === 'Disposal' || status === 'Expired') {
        queryStr += ` AND t.status_barang = $${paramCount}`;
        queryParams.push('Disposal');
      }
    }

    if (date) {
      paramCount++;
      queryStr += ` AND DATE(t.tanggal) = $${paramCount}`;
      queryParams.push(date);
    }

    queryStr += ' ORDER BY t.tanggal DESC';

    const result = await query(queryStr, queryParams);
    
    // Transform data dengan nama_gudang langsung dari JOIN
    const transformedData = result.rows.map(row => ({
      id: row.id_transaksi || row.kode_transaksi,
      transaction_id: row.kode_transaksi,
      type: row.status_barang === 'Masuk' ? 'RCV' : 
            row.status_barang === 'Assignment' ? 'ASS' : 'DISP',
      id_barang: row.id_barang,
      nama_barang: row.nama_barang,
      spesifikasi: row.jenis_barang,
      quantity: row.qty_stok,
      status: row.status_barang === 'Masuk' ? 'In Store' :
              row.status_barang === 'Assignment' ? 'In Use' : 'Disposal',
      nama: row.nama,
      npk: row.npk,
      location: row.nama_gudang || 'Unknown', // FIXED: Langsung dari JOIN
      keterangan: row.keterangan,
      datetime: row.tanggal
    }));

    res.json({
      success: true,
      data: transformedData,
      total: result.rowCount,
    });
  } catch (err) {
    console.error('❌ Error get transactions:', err.message);
    res.status(500).json({ 
      success: false, 
      message: 'Server error',
      error: err.message 
    });
  }
});

// Helper function untuk mapping location name ke id_gudang
async function getGudangId(locationName) {
  try {
    const result = await query('SELECT id_gudang FROM gudang WHERE nama_gudang = $1', [locationName]);

    if (result.rows.length > 0) {
      return result.rows[0].id_gudang;
    } else {
      throw new Error(`Gudang tidak ditemukan: ${locationName}`);
    }
  } catch (error) {
    console.error('Error getting gudang ID:', error);
    throw error;
  }
}

async function generateTransactionId(type) {
  try {
    let prefix = '';
    let statusFilter = '';
    
    switch(type) {
      case 'RCV':
        prefix = 'RCV';
        statusFilter = 'Masuk';
        break;
      case 'ASS':
        prefix = 'ASG';
        statusFilter = 'Assignment';
        break;
      case 'DISP':
        prefix = 'DPS';
        statusFilter = 'Disposal';
        break;
      default:
        prefix = 'TXN';
        statusFilter = '';
    }
    
    let countQuery = 'SELECT COUNT(*) as count FROM transaksi';
    let queryParams = [];
    
    if (statusFilter) {
      countQuery += ' WHERE status_barang = $1';
      queryParams.push(statusFilter);
    }
    
    const result = await query(countQuery, queryParams);
    const count = parseInt(result.rows[0].count) + 1;
    
    const formattedNumber = count.toString().padStart(5, '0');
    return `${prefix}${formattedNumber}`;
    
  } catch (error) {
    console.error('Error generating transaction ID:', error);
    return `${type}${Date.now()}`;
  }
}

// =======================
// GET Item by ID Barang - FIXED: Hanya item yang belum pernah keluar
// =======================
router.get('/items/:id_barang', async (req, res) => {
  const { id_barang } = req.params;
  
  try {
    console.log('🔍 Fetching item for auto-fill:', id_barang);
    
    // FIXED: Cek apakah item pernah keluar (Assignment atau Disposal)
    const checkExitQuery = `
      SELECT COUNT(*) as exit_count 
      FROM transaksi 
      WHERE id_barang = $1 
        AND status_barang IN ('Assignment', 'Disposal')
    `;
    
    const exitCheck = await query(checkExitQuery, [id_barang]);
    
    if (parseInt(exitCheck.rows[0].exit_count) > 0) {
      return res.status(404).json({
        success: false,
        message: 'ID Barang sudah keluar (Assignment/Disposal). Item tidak dapat digunakan lagi.'
      });
    }
    
    // Ambil data item dari transaksi Masuk terakhir
    const result = await query(
      `SELECT DISTINCT ON (id_barang) 
        id_barang, 
        nama_barang, 
        jenis_barang as spesifikasi
      FROM transaksi 
      WHERE id_barang = $1 
        AND status_barang = 'Masuk'
      ORDER BY id_barang, tanggal DESC
      LIMIT 1`,
      [id_barang]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'ID Barang tidak ditemukan dalam sistem.'
      });
    }

    const item = result.rows[0];
    
    res.json({
      success: true,
      data: {
        id_barang: item.id_barang,
        nama_barang: item.nama_barang,
        spesifikasi: item.spesifikasi || ''
      }
    });

  } catch (err) {
    console.error('❌ Error fetching item for auto-fill:', err.message);
    res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil data barang',
      error: err.message
    });
  }
});

// =======================
// GET Transaction by ID
// =======================
router.get('/transactions/:id', async (req, res) => {
  const { id } = req.params;

  try {
    // FIXED: Join dengan gudang
    const result = await query(
      `SELECT t.*, g.nama_gudang 
       FROM transaksi t 
       LEFT JOIN gudang g ON t.id_gudang = g.id_gudang 
       WHERE t.id_transaksi = $1`,
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan' });
    }

    const row = result.rows[0];
    const transformedData = {
      id: row.id_transaksi || row.kode_transaksi,
      transaction_id: row.kode_transaksi,
      type: row.status_barang === 'Masuk' ? 'RCV' : 
            row.status_barang === 'Assignment' ? 'ASS' : 'DISP',
      id_barang: row.id_barang,
      nama_barang: row.nama_barang,
      spesifikasi: row.jenis_barang,
      quantity: row.qty_stok,
      status: row.status_barang === 'Masuk' ? 'In Store' :
              row.status_barang === 'Assignment' ? 'In Use' : 'Disposal',
      nama: row.nama,
      npk: row.npk,
      location: row.nama_gudang || 'Unknown',
      keterangan: row.keterangan,
      datetime: row.tanggal
    };

    res.json({ success: true, data: transformedData });
  } catch (err) {
    console.error('❌ Error get transaction by ID:', err.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// =======================
// CREATE Transaksi Universal
// =======================
router.post('/', async (req, res) => {
  const { 
    kode_transaksi,
    type, 
    id_barang, 
    nama_barang, 
    jenis_barang, 
    qty_stok, 
    status_barang, 
    nama, 
    npk, 
    location, 
    keterangan, 
    datetime 
  } = req.body;

  try {
    console.log('📝 Request body:', req.body);

    if (!type || !id_barang || !nama_barang || !qty_stok || !location) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: type, id_barang, nama_barang, qty_stok, location'
      });
    }

    // FIXED: Cek apakah item sudah pernah keluar (untuk ASS/DISP)
    if (type === 'ASS' || type === 'DISP') {
      const checkQuery = `
        SELECT COUNT(*) as exit_count 
        FROM transaksi 
        WHERE id_barang = $1 
          AND status_barang IN ('Assignment', 'Disposal')
      `;
      
      const checkResult = await query(checkQuery, [id_barang]);
      
      if (parseInt(checkResult.rows[0].exit_count) > 0) {
        return res.status(400).json({
          success: false,
          message: 'ID Barang sudah pernah keluar. Tidak dapat digunakan lagi.'
        });
      }
    }

    const transactionId = uuidv4();
    const transactionCode = await generateTransactionId(type);
    
    let finalStatus;
    if (type === 'RCV') {
      finalStatus = 'Masuk';
    } else if (type === 'ASS') {
      finalStatus = 'Assignment';  
    } else if (type === 'DISP') {
      finalStatus = 'Disposal';
    } else {
      finalStatus = status_barang || 'Masuk';
    }

    const finalGudangId = await getGudangId(location);

    if (type === 'ASS' && (!nama || !npk)) {
      return res.status(400).json({
        success: false,
        message: 'Name and NPK are required for assignment transactions'
      });
    }

    let timestampValue;
    if (datetime) {
      const date = new Date(datetime);
      timestampValue = date.toISOString().slice(0, 19).replace('T', ' ');
    } else {
      const now = new Date();
      timestampValue = now.toISOString().slice(0, 19).replace('T', ' ');
    }

    const insertQuery = `
      INSERT INTO transaksi 
        (id_transaksi, kode_transaksi, id_barang, nama_barang, npk, nama, status_barang, qty_stok, tanggal, id_gudang, jenis_barang, keterangan) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) 
      RETURNING *
    `;

    const queryParams = [
      transactionId,
      transactionCode,
      id_barang, 
      nama_barang, 
      npk || null, 
      nama || null, 
      finalStatus, 
      parseInt(qty_stok), 
      timestampValue,
      finalGudangId, 
      jenis_barang || 'General',
      keterangan || ''
    ];

    const result = await query(insertQuery, queryParams);
    const newTransaction = result.rows[0];
    
    const transformedData = {
      id: newTransaction.id_transaksi || newTransaction.kode_transaksi,
      transaction_id: newTransaction.kode_transaksi,
      type: type,
      id_barang: newTransaction.id_barang,
      nama_barang: newTransaction.nama_barang,
      spesifikasi: newTransaction.jenis_barang,
      quantity: newTransaction.qty_stok,
      status: finalStatus === 'Masuk' ? 'In Store' :
              finalStatus === 'Assignment' ? 'In Use' : 'Disposal',
      nama: newTransaction.nama,
      npk: newTransaction.npk,
      location: location,
      keterangan: newTransaction.keterangan,
      datetime: newTransaction.tanggal
    };

    if (createTransactionNotification) {
      createTransactionNotification(transformedData, type);
    }

    res.status(201).json({ 
      success: true, 
      message: 'Transaction created successfully', 
      data: transformedData 
    });

  } catch (err) {
    console.error('❌ Error create transaction:', err.message);
    console.error('❌ Error stack:', err.stack);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to create transaction',
      error: err.message 
    });
  }
});

// Backward compatibility endpoints
router.post('/receiving', async (req, res) => {
  const { kode_transaksi, jenis_barang, id_barang, nama_barang, qty_stok, id_gudang, keterangan } = req.body;
  const transactionId = uuidv4();
  
  try {
    const result = await query(
      `INSERT INTO transaksi 
        (id_transaksi, kode_transaksi, jenis_barang, id_barang, nama_barang, status_barang, qty_stok, tanggal, id_gudang, keterangan) 
       VALUES ($1,$2,$3,$4,$5,'Masuk',$6,NOW(),$7,$8) 
       RETURNING *`,
      [transactionId, kode_transaksi, jenis_barang, id_barang, nama_barang, qty_stok, id_gudang, keterangan]
    );

    res.json({ success: true, message: 'Receiving berhasil ditambahkan', data: result.rows[0] });
  } catch (err) {
    console.error('❌ Error insert receiving:', err.message);
    res.status(500).json({ success: false, message: 'Gagal tambah transaksi' });
  }
});

router.post('/assignment', async (req, res) => {
  const { kode_transaksi, jenis_barang, id_barang, nama_barang, npk, nama, qty_stok, id_gudang, keterangan } = req.body;

  try {
    const result = await query(
      `INSERT INTO transaksi 
        (kode_transaksi, jenis_barang, id_barang, nama_barang, npk, nama, status_barang, qty_stok, tanggal, id_gudang, keterangan) 
       VALUES ($1,$2,$3,$4,$5,$6,'Assignment',$7,NOW(),$8,$9) 
       RETURNING *`,
      [kode_transaksi, jenis_barang, id_barang, nama_barang, npk, nama, qty_stok, id_gudang, keterangan]
    );

    res.json({ success: true, message: 'Assignment berhasil ditambahkan', data: result.rows[0] });
  } catch (err) {
    console.error('❌ Error insert assignment:', err.message);
    res.status(500).json({ success: false, message: 'Gagal tambah transaksi' });
  }
});

router.post('/disposal', async (req, res) => {
  const { kode_transaksi, jenis_barang, id_barang, nama_barang, npk, nama, qty_stok, id_gudang, keterangan } = req.body;

  try {
    const result = await query(
      `INSERT INTO transaksi 
        (kode_transaksi, jenis_barang, id_barang, nama_barang, status_barang, qty_stok, tanggal, id_gudang, keterangan) 
       VALUES ($1,$2,$3,$4,$5,$6,'Disposal',$7,NOW(),$8,$9) 
       RETURNING *`,
      [kode_transaksi, jenis_barang, id_barang, nama_barang, npk, nama, qty_stok, id_gudang, keterangan]
    );

    res.json({ success: true, message: 'Disposal berhasil ditambahkan', data: result.rows[0] });
  } catch (err) {
    console.error('❌ Error insert disposal:', err.message);
    res.status(500).json({ success: false, message: 'Gagal tambah transaksi' });
  }
});

router.get('/dashboard/stats', async (req, res) => {
  try {
    const result = await query(`
      SELECT 
        COUNT(*) AS total_transactions,
        COUNT(*) FILTER (WHERE status_barang = 'Masuk') AS total_masuk,
        COUNT(*) FILTER (WHERE status_barang = 'Assignment') AS total_assignment,
        COUNT(*) FILTER (WHERE status_barang = 'Disposal') AS total_disposal
      FROM transaksi
    `);

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('❌ Error dashboard stats:', err.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.setNotificationCreator = setNotificationCreator;

module.exports = router;