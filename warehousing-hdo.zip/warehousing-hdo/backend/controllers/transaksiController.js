const TransaksiModel = require('../models/transaksiModel');
const BarangModel = require('../models/barangModel');
const KaryawanModel = require('../models/karyawanModel');
const GudangModel = require('../models/gudangModel');

class TransaksiController {
  // Get transactions page
  static async getTransactionsPage(req, res) {
    try {
      // Get all data needed for the page
      const [transactions, barang, karyawan, gudang] = await Promise.all([
        TransaksiModel.getAll(),
        BarangModel.getAllWithStock(),
        KaryawanModel.getAll(),
        GudangModel.getAll()
      ]);

      res.render('pages/transaksi', {
        title: 'Transactions - WMS Help Desk',
        transactions,
        barang,
        karyawan,
        gudang,
        currentPage: 'transaksi'
      });
    } catch (error) {
      console.error('Error getting transactions page:', error);
      res.status(500).render('pages/error', {
        title: 'Error',
        message: 'Gagal memuat halaman transaksi',
        error: error.message
      });
    }
  }

  // API: Get all transactions
  static async getAllTransactions(req, res) {
    try {
      const { status, limit = 100, offset = 0 } = req.query;
      
      const transactions = await TransaksiModel.getAll(status, parseInt(limit), parseInt(offset));
      
      res.json({
        success: true,
        data: transactions,
        total: transactions.length
      });
    } catch (error) {
      console.error('Error getting all transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data transaksi',
        error: error.message
      });
    }
  }

  // API: Get transaction by ID
  static async getTransactionById(req, res) {
    try {
      const { id } = req.params;
      
      const transaction = await TransaksiModel.getById(id);
      
      if (!transaction) {
        return res.status(404).json({
          success: false,
          message: 'Transaksi tidak ditemukan'
        });
      }
      
      res.json({
        success: true,
        data: {
          transaction,
          details: [transaction] // Single transaction as details
        }
      });
    } catch (error) {
      console.error('Error getting transaction by ID:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil detail transaksi',
        error: error.message
      });
    }
  }

  // API: Create receiving transaction (Masuk)
  static async createReceiving(req, res) {
    try {
      const { npk, id_gudang, keterangan, items } = req.body;

      // Validate required fields
      if (!npk || !id_gudang || !items || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Data tidak lengkap. NPK, gudang, dan items harus diisi.'
        });
      }

      // Validate items
      for (const item of items) {
        if (!item.id_barang || !item.qty_stok || item.qty_stok <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Setiap item harus memiliki ID barang dan quantity yang valid.'
          });
        }
      }

      // Create transactions (one for each item)
      const transactionDataArray = items.map(item => ({
        id_barang: parseInt(item.id_barang),
        npk: npk,
        status_barang: 'Masuk',
        qty_stok: parseInt(item.qty_stok),
        id_gudang: parseInt(id_gudang),
        keterangan: keterangan || 'Penerimaan barang'
      }));

      const results = await TransaksiModel.createBatch(transactionDataArray);
      
      res.json({
        success: true,
        message: 'Transaksi penerimaan berhasil dibuat',
        data: results
      });
    } catch (error) {
      console.error('Error creating receiving transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal membuat transaksi penerimaan',
        error: error.message
      });
    }
  }

  // API: Create assignment transaction
  static async createAssignment(req, res) {
    try {
      const { npk, id_gudang, keterangan, items } = req.body;

      // Validate required fields
      if (!npk || !id_gudang || !items || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Data tidak lengkap. NPK, gudang, dan items harus diisi.'
        });
      }

      // Validate items and check stock
      for (const item of items) {
        if (!item.id_barang || !item.qty_stok || item.qty_stok <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Setiap item harus memiliki ID barang dan quantity yang valid.'
          });
        }

        // Check stock availability
        const stockCheck = await TransaksiModel.checkStockAvailability(
          item.id_barang, 
          id_gudang, 
          item.qty_stok
        );
        
        if (!stockCheck.available) {
          return res.status(400).json({
            success: false,
            message: stockCheck.message
          });
        }
      }

      // Create transactions (one for each item)
      const transactionDataArray = items.map(item => ({
        id_barang: parseInt(item.id_barang),
        npk: npk,
        status_barang: 'Assignment',
        qty_stok: parseInt(item.qty_stok),
        id_gudang: parseInt(id_gudang),
        keterangan: keterangan || 'Assignment barang ke karyawan'
      }));

      const results = await TransaksiModel.createBatch(transactionDataArray);
      
      res.json({
        success: true,
        message: 'Transaksi penugasan berhasil dibuat',
        data: results
      });
    } catch (error) {
      console.error('Error creating assignment transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal membuat transaksi penugasan',
        error: error.message
      });
    }
  }

  // API: Create disposal transaction
  static async createDisposal(req, res) {
    try {
      const { npk, id_gudang, keterangan, items } = req.body;

      // Validate required fields
      if (!npk || !id_gudang || !keterangan || !items || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Data tidak lengkap. NPK, gudang, alasan disposal, dan items harus diisi.'
        });
      }

      // Validate items and check stock
      for (const item of items) {
        if (!item.id_barang || !item.qty_stok || item.qty_stok <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Setiap item harus memiliki ID barang dan quantity yang valid.'
          });
        }

        // Check stock availability
        const stockCheck = await TransaksiModel.checkStockAvailability(
          item.id_barang, 
          id_gudang, 
          item.qty_stok
        );
        
        if (!stockCheck.available) {
          return res.status(400).json({
            success: false,
            message: stockCheck.message
          });
        }
      }

      // Create transactions (one for each item)
      const transactionDataArray = items.map(item => ({
        id_barang: parseInt(item.id_barang),
        npk: npk,
        status_barang: 'Disposal',
        qty_stok: parseInt(item.qty_stok),
        id_gudang: parseInt(id_gudang),
        keterangan: keterangan
      }));

      const results = await TransaksiModel.createBatch(transactionDataArray);
      
      res.json({
        success: true,
        message: 'Transaksi disposal berhasil dibuat',
        data: results
      });
    } catch (error) {
      console.error('Error creating disposal transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal membuat transaksi disposal',
        error: error.message
      });
    }
  }

  // API: Get dashboard statistics
  static async getDashboardStats(req, res) {
    try {
      const stats = await TransaksiModel.getDashboardStats();
      
      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error getting dashboard statistics:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil statistik dashboard',
        error: error.message
      });
    }
  }

  // API: Get available items for transaction
  static async getAvailableItems(req, res) {
    try {
      const { id_gudang } = req.query;
      
      if (!id_gudang) {
        return res.status(400).json({
          success: false,
          message: 'Gudang ID harus diisi'
        });
      }

      // Get available items in warehouse
      const items = await GudangModel.getAvailableItems(id_gudang);
      
      res.json({
        success: true,
        data: items
      });
    } catch (error) {
      console.error('Error getting available items:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data item tersedia',
        error: error.message
      });
    }
  }

  // API: Search transactions
  static async searchTransactions(req, res) {
    try {
      const { q } = req.query;
      
      if (!q || q.trim().length < 2) {
        return res.status(400).json({
          success: false,
          message: 'Query pencarian minimal 2 karakter'
        });
      }

      const results = await TransaksiModel.search(q.trim());
      
      res.json({
        success: true,
        data: results
      });
    } catch (error) {
      console.error('Error searching transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal melakukan pencarian',
        error: error.message
      });
    }
  }

  // API: Generate transaction report
  static async generateReport(req, res) {
    try {
      const filters = {
        startDate: req.query.start_date,
        endDate: req.query.end_date,
        status_barang: req.query.status,
        warehouseId: req.query.warehouse_id,
        employeeNpk: req.query.employee_npk,
        itemType: req.query.item_type
      };

      // Remove undefined filters
      Object.keys(filters).forEach(key => {
        if (filters[key] === undefined || filters[key] === '') {
          delete filters[key];
        }
      });

      const results = await TransaksiModel.generateReport(filters);
      
      res.json({
        success: true,
        data: results,
        filters: filters
      });
    } catch (error) {
      console.error('Error generating report:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal generate laporan',
        error: error.message
      });
    }
  }

  // API: Get employee transactions
  static async getEmployeeTransactions(req, res) {
    try {
      const { npk } = req.params;
      
      const transactions = await TransaksiModel.getByEmployee(npk);
      
      res.json({
        success: true,
        data: transactions
      });
    } catch (error) {
      console.error('Error getting employee transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil transaksi karyawan',
        error: error.message
      });
    }
  }

  // API: Check stock availability
  static async checkStock(req, res) {
    try {
      const { id_barang, id_gudang, qty_required } = req.query;
      
      if (!id_barang || !id_gudang || !qty_required) {
        return res.status(400).json({
          success: false,
          message: 'Parameter tidak lengkap'
        });
      }

      const stockCheck = await TransaksiModel.checkStockAvailability(
        parseInt(id_barang),
        parseInt(id_gudang),
        parseInt(qty_required)
      );
      
      res.json({
        success: true,
        data: stockCheck
      });
    } catch (error) {
      console.error('Error checking stock:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengecek stok',
        error: error.message
      });
    }
  }

  // API: Get transaction summary
  static async getTransactionSummary(req, res) {
    try {
      const summaryByStatus = await TransaksiModel.getSummaryByStatus();
      const monthlyStats = await TransaksiModel.getMonthlyStats(new Date().getFullYear());
      
      res.json({
        success: true,
        data: {
          byStatus: summaryByStatus,
          monthly: monthlyStats
        }
      });
    } catch (error) {
      console.error('Error getting transaction summary:', error);
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil ringkasan transaksi',
        error: error.message
      });
    }
  }
}

module.exports = TransaksiController;